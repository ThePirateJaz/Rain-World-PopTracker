# Variants

Variants can override many files, for example: items, maps, locations, layouts and scripts.

You override files by just putting them in the same place and with the name inside the variants' folder.
For example, if you want to override ``layouts/tracker.json`` in the ``var_itemsonly`` variant, simply place the file at
``var_itemsonly/layouts/tracker.json``.

In most cases overriding layouts is all you need so that's what I've done in this example.
